﻿
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
public class lab12scan : MonoBehaviour
{
    public Vector3 joe;
    public float moveSpeed;

    void Start()
    {
        moveSpeed = 2f;
    }

    void Update()
    {
        transform.Translate(Vector3.left * moveSpeed);
        joe = new Vector3(43f, -0.1f, -3f);
        if (transform.position.x < -45)
        {
            transform.position = joe;
        }
    }
}

