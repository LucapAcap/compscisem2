﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
public class practice162 : MonoBehaviour
{
    public Vector3 joe;
    public float moveSpeed;

    void Start()
    {
        moveSpeed = 1f;
    }

    void Update()
    {
        transform.Translate(Vector3.right * moveSpeed);
        joe = new Vector3(-15.76f, -0.09f, 0f);
        if (transform.position.x > 15.9)
        {
            transform.position = joe;
        }
        if (Input.GetKeyDown("1"))
        {
            moveSpeed=moveSpeed+1;
        }
        if (Input.GetKeyDown("2"))
        {
            moveSpeed = moveSpeed - 1;
        }
    }

    public void increaseSpeed()
    {
        moveSpeed = 3;
    }
    public void decreaseSpeed()
    {
        moveSpeed = 0.1f;
    }



}
