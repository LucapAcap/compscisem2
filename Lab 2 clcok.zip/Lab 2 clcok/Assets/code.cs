﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class code : MonoBehaviour {
	public int counter;
	
	void Start() {
	counter=0;
	print ("The value of counter is: "+ counter);
	}
	
	void Update() {
	counter=counter+1;
	print("The counter variable can also be changed here: "+counter);

	}
}
