﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
public class lab16recycle : MonoBehaviour
{
    public Vector3 joe;
    public float moveSpeed;

    void Start()
    {
        moveSpeed = 0.5f;
    }

    void Update()
    {
        transform.Translate(Vector3.right * moveSpeed);
        joe = new Vector3(-110.1f, -14.7f, -3f);
        if (transform.position.x > 54)
        {
            transform.position = joe;
        }
    }
}
