﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class code16movements : MonoBehaviour
{
    public Vector3 joe;
    public float moveSpeed;
    public float rotateSpeed;
    public Text obj;
    int counter;
    // Use this for initialization
    void Start()
    {
        obj.text = counter.ToString();
        counter = 0;
        moveSpeed = 2.5f;
    }

    // Update is called once per frame
    void Update()
    {
        obj.text = counter.ToString();
        if (Input.GetKey("w"))
        {
            transform.Translate(Vector3.up * moveSpeed);
        }
     
        if (Input.GetKey("s"))
        {
            transform.Translate(Vector3.down * moveSpeed);
        }
        if (Input.GetKeyDown("t"))
        {
            counter = counter + 1;
        }

    }
    void OnTriggerEnter2D(Collider2D coll)
    {
        print("Hello ben");
        counter = counter + 1;
    }

    void OnCollisionEnter2D(Collision2D coll)
    {

    }
}
