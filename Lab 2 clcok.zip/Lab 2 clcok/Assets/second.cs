﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class second : MonoBehaviour {
	public int sally;
	
	void Start () {
		print("I love donuts!");
		sally=0;
	}
	
	
	void Update () {
		print(sally);
	}
}
