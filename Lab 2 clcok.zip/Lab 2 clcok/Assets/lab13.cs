﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lab13 : MonoBehaviour {
    public Vector3 joe;
    public float r;
    public float y;
	// Use this for initialization
	void Start () {
        r = Random.Range(-25, 25);
        y = Random.Range(-8, 8);
        joe = new Vector3(r, y, 0f);
	}
	
	// Update is called once per frame
	void Update () {
        r = Random.Range(-25, 25);
        y = Random.Range(-8, 8);
        joe = new Vector3(r, y, 0f);
        transform.position = joe;
    }
}
