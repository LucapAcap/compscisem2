﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class qwqwqw : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        int temp = Random.Range(-5, 5);
        print(temp);
	}
}
